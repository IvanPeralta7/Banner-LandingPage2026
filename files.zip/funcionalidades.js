/* ============================================================
   ARCHIVO: funcionalidades.js
   DESCRIPCIÓN: Comportamientos dinámicos de la landing page.
   Contiene la animación del hero, el año automático
   en el footer y el efecto de aparición al hacer scroll.
   ============================================================ */


/* ────────────────────────────────────────────────────────────
   ANIMACIÓN DE LÍNEAS CONVERGENTES — HERO
   Dibuja líneas que se mueven desde los bordes hacia el
   centro del canvas, generando un efecto de movimiento
   tecnológico en el fondo del hero.
   ──────────────────────────────────────────────────────────── */
(function () {

  /* Referencia al elemento canvas del hero */
  const lienzo = document.getElementById('lienzo-hero');
  const contexto = lienzo.getContext('2d');

  /* Color de las líneas: debe coincidir con --color-acento en estilos.css */
  const COLOR_ACENTO = '#FF5300';

  /* Cantidad de líneas que se dibujan simultáneamente */
  const CANTIDAD_LINEAS = 18;

  /* Almacena el ancho y alto actuales del canvas */
  let anchoPantalla, altoPantalla;

  /* Array que contiene la configuración de cada línea */
  let lineas;

  /* ID del frame de animación actual (para cancelarlo si hace falta) */
  let idAnimacion;


  /* ── Ajusta el tamaño del canvas al tamaño real del contenedor ── */
  function ajustarTamano() {
    anchoPantalla = lienzo.width  = lienzo.offsetWidth;
    altoPantalla  = lienzo.height = lienzo.offsetHeight;
    inicializarLineas();
  }


  /* ── Crea o reinicia el array de líneas con posiciones aleatorias ── */
  function inicializarLineas() {
    lineas = Array.from({ length: CANTIDAD_LINEAS }, function () {
      /* Ángulo de partida aleatorio (en radianes) */
      const angulo = Math.random() * Math.PI * 2;
      /* Distancia desde el centro hasta el punto de origen */
      const distancia = 0.3 + Math.random() * 0.5;

      return {
        /* Coordenada X de origen (en el borde del canvas) */
        origenX: anchoPantalla / 2 + Math.cos(angulo) * anchoPantalla * distancia,
        /* Coordenada Y de origen */
        origenY: altoPantalla  / 2 + Math.sin(angulo) * altoPantalla  * distancia,
        /* Velocidad de desplazamiento hacia el centro */
        velocidad: 0.3 + Math.random() * 0.5,
        /* Longitud visual de la estela de la línea */
        longitud: 0.1 + Math.random() * 0.5,
        /* Desfase de fase para que las líneas no estén sincronizadas */
        fase: Math.random() * Math.PI * 2
      };
    });
  }


  /* ── Dibuja un frame de la animación y solicita el siguiente ── */
  function dibujarFrame(tiempoActual) {
    /* Limpia el canvas antes de redibujar */
    contexto.clearRect(0, 0, anchoPantalla, altoPantalla);

    /* Centro del canvas (destino de todas las líneas) */
    const centroX = anchoPantalla / 2;
    const centroY = altoPantalla  / 2;

    lineas.forEach(function (linea) {
      /* Progreso de 0 a 1 basado en el tiempo y la velocidad de la línea */
      const progreso = ((tiempoActual * linea.velocidad * 0.0003 + linea.fase) % 1);

      /* Posición actual del punto inicial de la estela */
      const puntoInicioX = linea.origenX + (centroX - linea.origenX) * progreso;
      const puntoInicioY = linea.origenY + (centroY - linea.origenY) * progreso;

      /* Posición actual del punto final de la estela (ligeramente adelantado) */
      const progresoFinal = Math.min(progreso + linea.longitud * 0.3, 1);
      const puntoFinX = linea.origenX + (centroX - linea.origenX) * progresoFinal;
      const puntoFinY = linea.origenY + (centroY - linea.origenY) * progresoFinal;

      /* Transparencia: máxima en el medio del recorrido, nula en los extremos */
      const transparencia = Math.sin(progreso * Math.PI) * 0.6;

      /* Dibuja el segmento de línea */
      contexto.beginPath();
      contexto.moveTo(puntoInicioX, puntoInicioY);
      contexto.lineTo(puntoFinX, puntoFinY);
      contexto.strokeStyle = COLOR_ACENTO;
      contexto.globalAlpha = transparencia;
      contexto.lineWidth   = 0.8;
      contexto.stroke();
    });

    /* Restablece opacidad antes de dibujar el punto central */
    contexto.globalAlpha = 1;

    /* Punto circular en el centro que representa el destino de las líneas */
    contexto.beginPath();
    contexto.arc(centroX, centroY, 2.5, 0, Math.PI * 2);
    contexto.fillStyle   = COLOR_ACENTO;
    contexto.globalAlpha = 0.7;
    contexto.fill();
    contexto.globalAlpha = 1;

    /* Solicita el siguiente frame de animación */
    idAnimacion = requestAnimationFrame(dibujarFrame);
  }


  /* ── Inicialización: ajusta tamaño y arranca la animación ── */
  window.addEventListener('resize', ajustarTamano);
  ajustarTamano();
  idAnimacion = requestAnimationFrame(dibujarFrame);

})();


/* ────────────────────────────────────────────────────────────
   AÑO AUTOMÁTICO EN EL FOOTER
   Inserta el año actual en el elemento con id "anio-actual"
   para que el copyright siempre esté actualizado.
   ──────────────────────────────────────────────────────────── */
(function () {

  const elementoAnio = document.getElementById('anio-actual');

  if (elementoAnio) {
    elementoAnio.textContent = new Date().getFullYear();
  }

})();


/* ────────────────────────────────────────────────────────────
   EFECTO DE APARICIÓN AL SCROLL
   Observa los elementos con clase "aparecer". Cuando uno
   entra al viewport, se le agrega la clase "visible" que
   dispara su transición CSS de entrada.
   ──────────────────────────────────────────────────────────── */
(function () {

  /* Selecciona todos los elementos que deben animarse al aparecer */
  const elementosAnimados = document.querySelectorAll('.aparecer');

  /* Opciones del observador: el elemento debe estar al menos un 12% visible */
  const opcionesObservador = { threshold: 0.12 };

  /* Función que se ejecuta cuando un elemento entra o sale del viewport */
  function alObservar(entradas, observador) {
    entradas.forEach(function (entrada) {
      if (entrada.isIntersecting) {
        /* Agrega la clase que activa la transición CSS */
        entrada.target.classList.add('visible');
        /* Deja de observar el elemento una vez que ya apareció */
        observador.unobserve(entrada.target);
      }
    });
  }

  const observador = new IntersectionObserver(alObservar, opcionesObservador);

  /* Registra cada elemento para ser observado */
  elementosAnimados.forEach(function (elemento) {
    observador.observe(elemento);
  });

})();
